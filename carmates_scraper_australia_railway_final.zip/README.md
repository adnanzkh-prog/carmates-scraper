# Carmates Scraper - Australian Market + Railway Deployment

## Features specific to Australia
- Default location: `australia` (can override with any city: sydney, melbourne, brisbane, perth, adelaide)
- Currency: **AUD** ($)
- Odometer unit: **km** (kilometres)

## Deploy to Railway
1. Push this repository to GitHub.
2. In Railway, create a new project from GitHub.
3. Railway will automatically detect the `railway.json` and start the backend.
4. Environment variables are pre‑configured.

## Frontend Integration
The backend accepts requests from your Cloudflare frontend: `https://carmates-scraper.pages.dev/` (CORS enabled).

## API Endpoints
- `POST /scrape` – start a scraping job (returns task_id)
- `GET /scrape/status/{task_id}` – check progress
- `GET /listings` – retrieve stored listings
- `GET /export/csv` – download all listings as CSV
- `GET /export/excel` – download as Excel
- `WS /ws/progress` – real‑time WebSocket updates

## Local Testing
```bash
python -m venv venv
source venv/bin/activate  # or venv\\Scripts\\activate on Windows
pip install -r backend/requirements.txt
playwright install chromium
cp .env.example .env
uvicorn backend.main:app --reload --port 8000
```

## Scraping Example
```bash
curl -X POST http://localhost:8000/scrape \
  -H "Content-Type: application/json" \
  -d '{"query":"Toyota Camry","location":"sydney","min_price":5000,"max_price":20000,"limit":30}'
```